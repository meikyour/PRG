
package org.japo.java.main;

/**
 *
 * @author (c) Raul Granel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
               
        //Constantes.
        final int LIM_INF = 0;
        final int LIM_SUP = 10;
        
        //Resolución / Cuenta.
        for (int i = LIM_INF; i < LIM_SUP; i++){
            System.out.printf("Hay %d elefante/s\n",  i);
    }
    }
}
