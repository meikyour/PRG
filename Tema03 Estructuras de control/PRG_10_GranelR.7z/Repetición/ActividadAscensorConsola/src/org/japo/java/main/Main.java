package org.japo.java.main;

//Importamos la clase Scanner.
import java.util.Scanner;
//Importamos la clase Locale.
import java.util.Locale;

/**
 *
 * @author (c) Raul Granel
 */
public class Main {

    public static void main(String[] args) {

        //Instanciación objeto Scanner.
        Scanner scn = new Scanner(System.in, "ISO-8859-1");
        //Instanciamos el objeto Locale.                        
        Locale lcl = new Locale("EN");
        scn.useLocale(lcl);

        //Constantes.
        final int NUM_PERSONAS = 5;
        final char PISO_MIN = '0';
        final char PISO_MAX = '9';

        //Variables.  
        char piso = '0';

        // Recorrer PERSONAS
        for (int persona = 1; persona < NUM_PERSONAS; persona++) {
            // Validar PISO
            boolean ascensorOK = true;
            do {
                // Entrar PISO
                boolean testOK = true;
                do {
                    try {
                        System.out.printf("Persona %d ---> ", persona);
                        piso = scn.nextLine().charAt(0);
                        testOK = false;
                    } catch (Exception e) {
                        System.out.println("Error entrada.");
                    }
                } while (testOK);
                ascensorOK = !(piso >= PISO_MIN && piso <= PISO_MAX);
                if (ascensorOK) {
                    System.out.println("Plantas 0...9");
                }
            } while (ascensorOK);

            //Mensaje.
            System.out.printf("Persona %d ---> %c\n", persona, piso);
        }
    }
}
