
package org.japo.java.main;

/**
 *
 * @author (c) Raul Granel
 */
public class Main {

    public static void main(String[] args) {
        
        System.out.printf("Hay %d elefante/s\n",  0);
        System.out.printf("Hay %d elefante/s\n",  1);
        System.out.printf("Hay %d elefante/s\n",  2);
        System.out.printf("Hay %d elefante/s\n",  3);
        System.out.printf("Hay %d elefante/s\n",  4);
        System.out.printf("Hay %d elefante/s\n",  5);
        System.out.printf("Hay %d elefante/s\n",  6);
        System.out.printf("Hay %d elefante/s\n",  7);
        System.out.printf("Hay %d elefante/s\n",  8);
        System.out.printf("Hay %d elefante/s\n",  9);
    }  
}
