
package org.japo.java.main;

/**
 *
 * @author (c) Raul Granel
 */
public class Main {

    public static void main(String[] args) {
        
        //Constantes.
        final int LIM_INF = 0;
        final int LIM_SUP = 10;
        
        //Variable.
        int i = LIM_INF; 
        
        while (i < LIM_SUP){
            System.out.printf("Hay %d elefante/s\n",  i);
            i++;
        }
        //Resultado de imprimirá el programa.
        //System.out.printf("Hay %d elefante/s\n",  1);
        //System.out.printf("Hay %d elefante/s\n",  1);
        //System.out.printf("Hay %d elefante/s\n",  2);
        //System.out.printf("Hay %d elefante/s\n",  3);
        //System.out.printf("Hay %d elefante/s\n",  4);
        //System.out.printf("Hay %d elefante/s\n",  5);
        //System.out.printf("Hay %d elefante/s\n",  6);
        //System.out.printf("Hay %d elefante/s\n",  7);
        //System.out.printf("Hay %d elefante/s\n",  8);
        //System.out.printf("Hay %d elefante/s\n",  9);
    }
}