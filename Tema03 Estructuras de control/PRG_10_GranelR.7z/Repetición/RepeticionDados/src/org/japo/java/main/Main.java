package org.japo.java.main;

//Importación clase Random.
import java.util.Random;

/**
 *
 * @author (c) Raul Granel
 */
public class Main {

    public static void main(String[] args) {

        //Intancia objeto Random.
        Random rnd = new Random(System.currentTimeMillis());

        //Constantes.
        final int TIRADAS_MAXIMAS = 20;
        final int TIRADAS_MINIMAS = 1;

        //Variables.
        //Veces que a salido el número siete.
        int vecesSiete = 0;

        //Veces que se tira el dado.
        for (int tiradas = 0; tiradas <= TIRADAS_MAXIMAS; tiradas++) {
            int resultadoTirada = rnd.nextInt(TIRADAS_MAXIMAS - TIRADAS_MINIMAS + 1);
            System.out.println("Ha salido al tirar el dado: " + resultadoTirada);
            //Veces que a salido el número siete.
            if (resultadoTirada == 7) {
                vecesSiete++;
            }
        }
        //Variable de porcentaje de veces que a salido el número siete.
        int porcentajeSiete = vecesSiete * 100 / TIRADAS_MAXIMAS;

        //Respuestas.
        System.out.println("Ya ha tirado el dado " + TIRADAS_MAXIMAS + " veces");
        System.out.println("Estas son las veces que ha salido el número siete en las tiradas: " + vecesSiete);
        System.out.println("Este es el porcentaje de veces que a salido el número siete: " + porcentajeSiete + "%");
    }
}
