# TERMS OF USE
You can use the whole code or parts of it if you respect this
if this code is useful for you you should send me a pretty postal card.


# ACKNOWLEDGEMENTS
The whole code of this project has been written by me.

